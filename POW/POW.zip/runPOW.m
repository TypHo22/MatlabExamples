clear all;
clc
[Result]=POW(2,5)
