clc;
%Erzeugt mir einen Vektor mit randomzahlen von 1-100, 10 lang
vector2sort=randi(100,1,10) %Erzeugt mir einen Vektor mit randomzahlen von 1-100, 10 lang

sortedVector=SortOWN(vector2sort)